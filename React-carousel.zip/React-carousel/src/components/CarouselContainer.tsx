import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../store';
import MyCarousel from './Carousel';
import { addMediaItem } from '../store/actions';

interface CarouselContainerProps {}

const CarouselContainer: React.FC<CarouselContainerProps> = () => {
  const [visibleCards, setVisibleCards] = useState<number>(4);
  const handleSelectChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setVisibleCards(Number(event.target.value));
  };

  const styles = {
    addButton: {
      position: 'absolute',
      bottom: 20,
      left: 20,
      borderRadius: '5px',
      padding: '5px 10px',
      backgroundColor: 'green',
      color: 'white',
      border: 'none',
      cursor: 'pointer',
    },
  };

  const mediaItems = useSelector((state: RootState) => state.media);
  const dispatch = useDispatch();

  const handleAddCard = () => {
    const id = mediaItems.length + 1;
    dispatch(addMediaItem({ id, type: 'image', url: 'https://source.unsplash.com/random/' + id, title: '' }));
  };

  return (
    <>
      <div style={{ margin: 50 }}>
        <label htmlFor="visibleCards">Number of Visible Cards:</label>
        <input style={{ width: 100 }} min={1} max={4} type='number' id="visibleCards" value={visibleCards} onChange={handleSelectChange} />
      </div>
      <MyCarousel mediaPerPage={visibleCards} />
      <button style={styles.addButton} onClick={handleAddCard}>Add Card</button>
    </>
  );
};

export default CarouselContainer;
